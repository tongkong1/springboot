package com.tudou.springbootorderid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootOrderIdApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootOrderIdApplication.class, args);
    }


}
