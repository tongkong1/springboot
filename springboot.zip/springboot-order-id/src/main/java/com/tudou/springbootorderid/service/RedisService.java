package com.tudou.springbootorderid.service;

import cn.hutool.core.date.DateUtil;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.Set;

/**
 * redis操作类
 *
 * @version V1.0
 * @Title: RedisUtil.java
 * @Package com.tudou.springbootorderid.utils
 * @author: zhaoyuanyuan
 * @date: 2021/1/12 17:26
 */
@Component
public class RedisService {

    @Autowired
    private RedisTemplate redisTemplate;

    public Long getIncrValue(String key){
        ValueOperations valueOperations = redisTemplate.opsForValue();
        redisTemplate.setValueSerializer(new StringRedisSerializer());
        Long incrementId = valueOperations.increment(key, 1);
        return  incrementId;
    }

    public void zSet(final String key,final Object value,Double score){
        redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
        ZSetOperations zSetOperations = redisTemplate.opsForZSet();
        zSetOperations.add(key, value, score);
    }

    //取出Zset
    public Set zRange(final String key){
        redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
        ZSetOperations zSetOperations = redisTemplate.opsForZSet();

        Set result = null;
        try {
            result = zSetOperations.range(key, 0, zSetOperations.size(key));
        } catch (Exception e) {
            result = null;
            e.printStackTrace();
        }
        return result;
    }
}
