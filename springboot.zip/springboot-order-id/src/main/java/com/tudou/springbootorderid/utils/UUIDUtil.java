package com.tudou.springbootorderid.utils;

import java.util.UUID;

/**
 * 获取UUID
 *
 * @version V1.0
 * @Title: UUIDUtil.java
 * @Package com.tudou.springbootorderid.utils
 * @author: zhaoyuanyuan
 * @date: 2020/12/28 16:30
 */
public class UUIDUtil {

    public static String generateUUID(){
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }

    public static void main(String[] args) {
        System.out.println(generateUUID());
    }


}
