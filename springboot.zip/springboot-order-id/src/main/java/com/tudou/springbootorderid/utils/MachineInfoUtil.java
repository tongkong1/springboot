package com.tudou.springbootorderid.utils;

import java.io.IOException;
import java.io.InputStream;

/**
 * 获取机器信息
 *
 * @version V1.0
 * @Title: MechineInfoUtil.java
 * @Package com.tudou.springbootorderid.utils
 * @author: zhaoyuanyuan
 * @date: 2021/1/16 17:51
 */
public class MachineInfoUtil {

    public static void main(String[] args) {
        getMachineNo();
    }

    public static void getMachineNo(){
        try {
            Process process = Runtime.getRuntime().exec(new String[] { "wmic", "cpu", "get", "ProcessorId" });
            InputStream in = process.getInputStream();
            byte[] b = new byte[128];
            int len = -1;
            while ((len = in.read(b)) != -1){
                System.out.println(new String(b,0,len));
            }
            in.close();
            process.destroy();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
