package com.tudou.springbootorderid.controller;

import cn.hutool.core.date.DateUtil;
import com.tudou.springbootorderid.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.Set;
import java.util.UUID;

/**
 * redis controller测试类
 *
 * @version V1.0
 * @Title: RedisController.java
 * @Package com.tudou.springbootorderid.controller
 * @author: zhaoyuanyuan
 * @date: 2021/1/13 11:10
 */
@RestController
public class RedisController {

    @Autowired
    private RedisService redisService;

    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping("/getIncrementId")
    public String getIncrementId(){
        String currentTime = DateUtil.format(new Date(), "yyyyMMddHHmmss");
        String key = "id_"+ currentTime;
        Long incrValue = redisService.getIncrValue(key);
        String id =currentTime+incrValue;
        return id;
    }

}
