package com.tudou.springbootrabbitmq.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 扇形交换机配置类
 *  扇形交换机没有路由概念，就算绑定了路由键也是无视的，这个交换机接收到消息后，会直接转发到与其绑定的所有队列上，类似于广播的性质
 * @version V1.0
 * @Title: FanoutExchangeConfig.java
 * @Package com.tudou.springbootrabbitmq.config
 * @date: 2020/11/17 10:20
 */
@Configuration
public class FanoutExchangeConfig {

    public final static String FANOUT_QUEUE_A = "fanout.queue.A";

    public final static String FANOUT_QUEUE_B = "fanout.queue.B";

    public final static String FANOUT_EXCHANGE_NAME = "fanoutExchange";
    /**
     *  创建三个队列ABC
     * @return org.springframework.amqp.core.Queue
     * @author zhaoyuanyuan
     * @date 2020/11/17
     * @throws
     * @update
     * @see  FanoutExchangeConfig queueA()
     * @since V1.0
     */
    @Bean
    public Queue fanoutQueueA(){
        return new Queue(FANOUT_QUEUE_A);
    }

    @Bean
    public Queue fanoutQueueB(){
        return new Queue(FANOUT_QUEUE_B);
    }

    /**
     *  创建交换机
     * @return org.springframework.amqp.core.FanoutExchange
     * @author zhaoyuanyuan
     * @date 2020/11/17
     * @throws
     * @update
     * @see  FanoutExchangeConfig fanoutExchange()
     * @since V1.0
     */
    @Bean
    FanoutExchange fanoutExchange() {
        return new FanoutExchange(FANOUT_EXCHANGE_NAME);
    }

    /**
     * 绑定队列和扇形交换机
     * @return org.springframework.amqp.core.Binding
     * @author zhaoyuanyuan
     * @date 2020/11/17
     * @throws
     * @update
     * @see  FanoutExchangeConfig bindingFanoutExchangeA()
     * @since V1.0
     */
    @Bean
    Binding bindingFanoutExchangeA() {
        return BindingBuilder.bind(fanoutQueueA()).to(fanoutExchange());
    }

    @Bean
    Binding bindingFanoutExchangeB() {
        return BindingBuilder.bind(fanoutQueueB()).to(fanoutExchange());
    }

}
