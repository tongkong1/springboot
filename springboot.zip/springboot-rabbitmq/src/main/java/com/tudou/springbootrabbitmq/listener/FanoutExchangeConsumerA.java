package com.tudou.springbootrabbitmq.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 消费者-测试扇形交换机
 *
 * @version V1.0
 * @Title: FanoutExchangeConsumer.java
 * @Package com.tudou.springbootrabbitmq.listener
 * @date: 2020/11/17 10:42
 */
@Component
@RabbitListener(queues = "fanout.queue.A")
public class FanoutExchangeConsumerA {

    @RabbitHandler
    public void consume(String message){
        System.out.println("收到来自fanout交换机-queueA的消息："+message);
    }
}
