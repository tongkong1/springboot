package com.tudou.springbootrabbitmq.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * 直接型交换机配置类
 * @version V1.0
 * @Title: DirectExchangeConfig.java
 * @Package com.tudou.springbootrabbitmq.config
 * @date: 2020/11/11 14:35
 */
@Configuration
public class DirectExchangeConfig {

    /**
     * 创建队列
     * Queue(String name, boolean durable)
     *  name: 队列名字
     *  durable：是否持久化,默认是false
     *  持久化队列：会被存储在磁盘上，当消息代理重启时仍然存在，暂存队列：当前连接有效
     * @return org.springframework.amqp.core.Queue
     * @see  DirectExchangeConfig DirectQueueDemo()
     * @since V1.0
     */
    @Bean
    public Queue queueDemo(){
        return new Queue("queue1-direct-test",true);
    }

    /**
     *  创建交换机
     *  DirectExchange(String name, boolean durable, boolean autoDelete)
     *      name: 交换机名称
     *      durable：是否持久化，默认是false,表示暂存队列，只有当前链接有效；如果为true:表示持久化队列，会被存储在磁盘上
     *      autoDelete：是否自动删除，默认是false。当没有生产者或者消费者使用这个交换机时将会被删除
     * @return org.springframework.amqp.core.DirectExchange
     * @date 2020/11/11
     * @see  DirectExchangeConfig directExchangeDemo()
     * @since V1.0
     */
    @Bean
    DirectExchange directExchangeDemo(){
        return new DirectExchange("direct-exchange-1",true,false);
    }

    /**
     * 将队列和直接型交换机绑定，并设置匹配键为：direct-queue-routing
     * @return org.springframework.amqp.core.Binding
     * @date 2020/11/11
     * @see  DirectExchangeConfig bindingDirectQueue()
     * @since V1.0
     */
    @Bean
    Binding bindingDirectQueue(){
        Binding binding = BindingBuilder.bind(queueDemo())
                .to(directExchangeDemo())
                .with("direct-queue-key");
        return binding;
    }



}
