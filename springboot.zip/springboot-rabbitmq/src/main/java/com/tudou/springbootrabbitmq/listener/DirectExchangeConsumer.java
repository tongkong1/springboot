package com.tudou.springbootrabbitmq.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 测试直接交换机
 *
 * @version V1.0
 * @Title: DirectExchangeConsumer.java
 * @Package com.tudou.springbootrabbitmq.listener
 * @date: 2020/11/11 15:44
 */
@Component
@RabbitListener(queues = "queue1-direct-test")
public class DirectExchangeConsumer {

    @RabbitHandler
    public void consumerDirectMsg(String meaasge){
        System.out.println("DirectExchangeConsumer收到消息："+meaasge);
    }
}
