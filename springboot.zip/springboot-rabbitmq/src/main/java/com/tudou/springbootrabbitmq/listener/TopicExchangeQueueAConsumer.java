package com.tudou.springbootrabbitmq.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 主题交换机-无匹配符的路由key
 *
 * @version V1.0
 * @Title: TopicExchangeQueueAConsumer.java
 * @Package com.tudou.springbootrabbitmq.listener
 * @date: 2020/11/13 16:25
 */
@Component
@RabbitListener(queues = "queueA")
public class TopicExchangeQueueAConsumer {


    @RabbitHandler
    public void consumerA(String message){
        System.out.println("queueA收到消息为："+message);
    }
}
