package com.tudou.springbootrabbitmq.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 主题交换机配置类
 *
 * @version V1.0
 * @Title: TopicExchangeConfig.java
 * @Package com.tudou.springbootrabbitmq.config
 * @date: 2020/11/13 15:59
 */
@Configuration
public class TopicExchangeConfig {

    public final static String KEY1 = "topic.key.A";

    public final static String KEY2 = "topic.key.B";

    public final static String KEY3 = "topic.key.*";

    public final static String KEY4 = "topic.key.#";

    public final static String KEY5 = "topic.key.CC.DD";

    public final static String TOPIC_EXCHANGE_NAME = "topicExchange";

    /**
     *  创建队列B
     * @return org.springframework.amqp.core.Queue
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig queueA()
     * @since V1.0
     */
    @Bean
    public Queue queueA(){
        return new Queue("queueA");
    }

    /**
     *  创建队列B
     * @return org.springframework.amqp.core.Queue
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig queueB()
     * @since V1.0
     */
    @Bean
    public Queue queueB(){
        return new Queue("queueB");
    }

    /**
     *  创建队列c
     * @return org.springframework.amqp.core.Queue
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig queueB()
     * @since V1.0
     */
    @Bean
    public Queue queueC(){
        return new Queue("queueC");
    }

    /**
     *  创建交换机
     * @return org.springframework.amqp.core.TopicExchange
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig getTopicExchange()
     * @since V1.0
     */
    @Bean
    TopicExchange getTopicExchange(){
        return new TopicExchange(TOPIC_EXCHANGE_NAME);
    }

    /**
     *  队列A和交换机绑定，绑定的key为 topic.key.A，即只有消息携带的路由key为topic.key.A，才能发送到queueA
     * @return org.springframework.amqp.core.Binding
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig bindingExchangeQueueA()
     * @since V1.0
     */
    @Bean
    Binding bindingExchangeQueueA(){
        return BindingBuilder.bind(queueA()).to(getTopicExchange()).with(KEY1);
    }

    /**
     *  队列B和交换机绑定，绑定的key为 topic.key.*，即只有消息携带的路由key以为topic.key开头，才能发送到queueB
     * @return org.springframework.amqp.core.Binding
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig bindingExchangeQueueB()
     * @since V1.0
     */
    @Bean
    Binding bindingExchangeQueueB(){
        return BindingBuilder.bind(queueB()).to(getTopicExchange()).with(KEY3);
    }

    /**
     *  队列C和交换机绑定，绑定的key为 topic.key.#，即只有消息携带的路由key以为topic.key开头，#表示一个或多个单词，
     *  比如topic.key.CC.DD才能发送到queueB
     * @return org.springframework.amqp.core.Binding
     * @date 2020/11/13
     * @throws
     * @update
     * @see  TopicExchangeConfig bindingExchangeQueueB()
     * @since V1.0
     */
    @Bean
    Binding bindingExchangeQueueC(){
        return BindingBuilder.bind(queueC()).to(getTopicExchange()).with(KEY4);
    }


}
