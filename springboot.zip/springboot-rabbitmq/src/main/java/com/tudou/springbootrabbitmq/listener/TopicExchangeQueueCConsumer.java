package com.tudou.springbootrabbitmq.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 主题交换机-测试带#的路由key
 *
 * @version V1.0
 * @Title: TopicExchangeQueueAConsumer.java
 * @Package com.tudou.springbootrabbitmq.listener
 * @date: 2020/11/13 16:25
 */
@Component
@RabbitListener(queues = "queueC")
public class TopicExchangeQueueCConsumer {


    @RabbitHandler
    public void consumerA(String message){
        System.out.println("queueC收到消息为："+message);
    }
}
