package com.tudou.springbootrabbitmq.controller;

import com.tudou.springbootrabbitmq.config.FanoutExchangeConfig;
import com.tudou.springbootrabbitmq.config.TopicExchangeConfig;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 生产者
 *
 * @version V1.0
 * @Title: Provider.java
 * @Package com.tudou.springbootrabbitmq.controller
 * @date: 2020/11/11 15:22
 */
@RestController
public class ProviderController {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @GetMapping("/sendDirectMessage")
    public String sendDirectMessage(){

        String message = "direct message!!!";
        rabbitTemplate.convertAndSend("direct-exchange-1","direct-queue-key",message);
        /*for (int i=0; i<=10;i++){
            String message = "第"+i+"次，direct message!!!";
            rabbitTemplate.convertAndSend("direct-exchange-1","direct-queue-key",message);
            System.out.println("sendDirectMessage发送消息："+message);
            try{
                Thread.sleep(500);
            }catch (Exception e){ }

        }*/

        return "successful";
    }


    @GetMapping("/sendTopicMessage")
    public String sendTopicMessage(){
        String key = TopicExchangeConfig.KEY1;
        String message = "主题交换机测试，路由键为:"+ key;
        //预期：队列ABC均可收到消息
        rabbitTemplate.convertAndSend(TopicExchangeConfig.TOPIC_EXCHANGE_NAME,key,message);

        return "successful";
    }


    @GetMapping("/sendTopicMessage2")
    public String sendTopicMessage2(){
        String key = TopicExchangeConfig.KEY3;
        String message = "主题交换机测试，路由键为:"+ key;
        //预期：队列BC均可收到消息
        rabbitTemplate.convertAndSend(TopicExchangeConfig.TOPIC_EXCHANGE_NAME,key,message);

        return "successful";
    }

    @GetMapping("/sendTopicMessage3")
    public String sendTopicMessage3(){
        //String key = TopicExchangeConfig.KEY4;
        String key = TopicExchangeConfig.KEY5;
        String message = "主题交换机测试，路由键为:"+ key;
        //预期：队列C可收到消息
        rabbitTemplate.convertAndSend(TopicExchangeConfig.TOPIC_EXCHANGE_NAME,key,message);

        return "successful";
    }

    @GetMapping("/sendFanoutMessage")
    public String sendFanoutMessage(){
        String message = "send message to fanout exchange!!";
        rabbitTemplate.convertAndSend(FanoutExchangeConfig.FANOUT_EXCHANGE_NAME,null,message);
        return "successful";
    }

}
