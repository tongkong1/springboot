package com.tudou.springbootrabbitmq.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 测试主题交换机-带通配符*的路由键
 *
 * @version V1.0
 * @Title: TopicExchangeQueueAConsumer.java
 * @Package com.tudou.springbootrabbitmq.listener
 * @date: 2020/11/13 16:25
 */
@Component
@RabbitListener(queues = "queueB")
public class TopicExchangeQueueABConsumer {

    @RabbitHandler
    public void consumerA(String message){
        System.out.println("queueB收到消息为："+message);
    }
}