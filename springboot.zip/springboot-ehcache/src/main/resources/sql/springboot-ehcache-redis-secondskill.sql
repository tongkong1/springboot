CREATE TABLE book (
  id     bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  name     varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  price     decimal(10, 2) NULL DEFAULT NULL,
  amount     int(11) UNSIGNED NULL DEFAULT NULL,
  seconds_kill     int(11) NULL DEFAULT NULL,
  PRIMARY KEY (    id    ) USING BTREE
);
CREATE TABLE book_order (
  id     bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id     varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  book_id     bigint(20) NULL DEFAULT NULL,
  money     decimal(10, 2) NULL DEFAULT NULL,
  user_id     int(11) NULL DEFAULT NULL,
  status     int(11) NULL DEFAULT NULL,
  create_time     datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (    id    ) USING BTREE
);

INSERT INTO     book     VALUES (1, '三国演义', 200.00, 206666, NULL);
INSERT INTO     book     VALUES (2, '水浒传', 125.90, 185869, NULL);
INSERT INTO     book     VALUES (3, '西游记', 130.00, 8899, NULL);
INSERT INTO     book     VALUES (4, '红楼梦', 69.88, 289, NULL);
INSERT INTO     book     VALUES (5, '数据结构与算法', 79.50, 1200, NULL);
INSERT INTO     book     VALUES (6, '重新定义springcloud实战', 188.99, 55700, NULL);
INSERT INTO     book     VALUES (7, 'Hadoop权威指南', 99.00, 338, NULL);
INSERT INTO     book     VALUES (8, 'mysql技术内幕', 85.00, 1208, NULL);
INSERT INTO     book     VALUES (9, 'kafka权威指南', 120.00, 2865, NULL);
INSERT INTO     book     VALUES (10, '大话数据结构', 89.00, 6868, NULL);
INSERT INTO     book     VALUES (11, '三国演义', 69.00, 0, 1);
INSERT INTO     book     VALUES (12, '水浒传', 59.00, 0, 1);
INSERT INTO     book     VALUES (13, '西游记', 59.00, 0, 1);
INSERT INTO     book     VALUES (14, '红楼梦', 59.00, 0, 1);