package com.bobo.springbootehcache.controller;


import com.bobo.springbootehcache.entity.Book;
import com.bobo.springbootehcache.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/listall")
    public List<Book> listBooks(){
        return bookService.listBooks();
    }

    @PostMapping("/update")
    public String updateBook(Book book){
        bookService.updateBook(book);
        return "更新成功";
    }
}
