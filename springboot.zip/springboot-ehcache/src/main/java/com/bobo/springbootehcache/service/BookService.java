package com.bobo.springbootehcache.service;


import com.bobo.springbootehcache.entity.Book;

import java.util.List;


public interface BookService {

    /**
     * 更新book
     */
    Book updateBook(Book book);

    /**
     * 查询所有的book
     */
    List<Book> listBooks();
}
