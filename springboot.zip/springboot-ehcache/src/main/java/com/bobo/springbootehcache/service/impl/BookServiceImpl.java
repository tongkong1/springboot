package com.bobo.springbootehcache.service.impl;


import com.bobo.springbootehcache.entity.Book;
import com.bobo.springbootehcache.mapper.BookMapper;
import com.bobo.springbootehcache.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookMapper bookMapper;

    @Override
    @CacheEvict(cacheNames = {"allbooks"},allEntries = true)
    public Book updateBook(Book book) {
        bookMapper.updateBook(book);
        return book;
    }


    @Override
    @Cacheable(cacheNames = {"allbooks"},key = "#root.targetClass+'.listBooks'")
    public List<Book> listBooks() {
        return bookMapper.selectBooks(null);
    }

}
