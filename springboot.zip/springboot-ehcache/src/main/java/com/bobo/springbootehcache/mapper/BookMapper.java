package com.bobo.springbootehcache.mapper;

import com.bobo.springbootehcache.entity.Book;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface BookMapper {
    /**
     * 根据条件查询book
     */
    List<Book> selectBooks(@Param("book") Book book);

    /**
     * 根据条件更新book
     */
    int updateBook(@Param("book") Book book);
}
