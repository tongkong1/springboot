package com.bobo.springbootredis.mapper;


import com.bobo.springbootredis.entity.Book;

public interface BookMapper {
    /**
     * 根据ID获取book
     */
    Book selectBookById(Long id);

}
