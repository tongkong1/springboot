package com.bobo.springbootredis.service.impl;
import com.bobo.springbootredis.entity.Book;
import com.bobo.springbootredis.mapper.BookMapper;
import com.bobo.springbootredis.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookMapper bookMapper;

    @Override
    @Cacheable(cacheNames = {"single_book"},key = "#root.targetClass+'.'+#root.methodName+'.'+#p0",
            unless = "#result == null")
    public Book getBook(Long id){
        return bookMapper.selectBookById(id);
    }

}
