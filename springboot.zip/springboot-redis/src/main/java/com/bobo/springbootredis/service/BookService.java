package com.bobo.springbootredis.service;


import com.bobo.springbootredis.entity.Book;


public interface BookService {
    /**
     * 根据ID获取book
     */
    Book getBook(Long id);
}
