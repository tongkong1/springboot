package com.bobo.springbootsecondskill.service;


import com.bobo.springbootsecondskill.entity.Order;

public interface OrderService {
    /**
     * redis预扣库存，消息队列异步下单
     */
    boolean addOrder(Long bookId, Integer userId);

    /**
     * 真正下单，订单表插入记录，同时book表扣减库存
     */
    boolean addOrder(Order order);
}
