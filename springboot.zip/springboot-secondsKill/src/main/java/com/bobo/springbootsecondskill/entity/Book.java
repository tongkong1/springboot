package com.bobo.springbootsecondskill.entity;

import java.io.Serializable;
import java.math.BigDecimal;


public class Book implements Serializable {

    private static final long serialVersionUID = -5095285519170350640L;
    private Long id;
    private String name;
    private BigDecimal price;
    private Integer amount;
    private Integer secondsKill;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getSecondsKill() {
        return secondsKill;
    }

    public void setSecondsKill(Integer secondsKill) {
        this.secondsKill = secondsKill;
    }
}
