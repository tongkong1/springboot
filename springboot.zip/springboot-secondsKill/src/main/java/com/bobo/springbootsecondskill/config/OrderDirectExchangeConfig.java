package com.bobo.springbootsecondskill.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class OrderDirectExchangeConfig {
    public static final String QUEUE_NAME = "order-queue";
    public static final String EXCHANGE_NAME = "order-direct-exchange";
    public static final String QUEUE_EXCHANGE_KEY = "order-queue-exchange-key";


    /**
     * 创建队列
     */
    @Bean
    public Queue orderQueue(){
        return new Queue(QUEUE_NAME,true);
    }

    /**
     * 创建交换机
     */
    @Bean
    DirectExchange orderDirectExchange(){
        return new DirectExchange(EXCHANGE_NAME,true,false);
    }

    /**
     * 将队列和直接型交换机绑定，并设置匹配键
     */
    @Bean
    Binding bindQueueExchange(){
        return BindingBuilder.bind(orderQueue())
                .to(orderDirectExchange())
                .with(QUEUE_EXCHANGE_KEY);
    }

}
