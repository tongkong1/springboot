package com.bobo.springbootsecondskill.mapper;


import com.bobo.springbootsecondskill.entity.Book;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BookMapper {
    /**
     * 根据条件更新book
     */
    int updateBook(@Param("book") Book book);

    /**
     * 根据ID查询book
     */
    Book selectBookById(Long id);

    /**
     * 根据条件查询book
     */
    List<Book> selectBooks(@Param("book") Book book);
}
