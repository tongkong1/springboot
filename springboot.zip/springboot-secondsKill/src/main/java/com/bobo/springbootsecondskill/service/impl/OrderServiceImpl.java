package com.bobo.springbootsecondskill.service.impl;

import com.bobo.springbootsecondskill.entity.Book;
import com.bobo.springbootsecondskill.entity.Order;
import com.bobo.springbootsecondskill.listener.ApplicationEventListener;
import com.bobo.springbootsecondskill.mapper.BookMapper;
import com.bobo.springbootsecondskill.mapper.OrderMapper;
import com.bobo.springbootsecondskill.service.OrderProducer;
import com.bobo.springbootsecondskill.service.OrderService;
import com.bobo.springbootsecondskill.util.SnowflakeIdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.scripting.support.ResourceScriptSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Service
@Transactional
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderProducer orderProducer;
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;
    @Autowired
    private BookMapper bookMapper;
    @Autowired
    private OrderMapper orderMapper;

    @Override
    public boolean addOrder(Long bookId,Integer userId) {

        DefaultRedisScript<String> redisScript = new DefaultRedisScript();
        // 设置lua脚本
        redisScript.setScriptSource(new ResourceScriptSource(new ClassPathResource("stock_simple.lua")));
        redisScript.setResultType(String.class);
        List<String> keys = new ArrayList<>();
        keys.add(ApplicationEventListener.SECONDS_BOOK_KEY);
        StringRedisSerializer serializer = new StringRedisSerializer();
        // 执行lua脚本
        String res = redisTemplate.execute(redisScript,serializer,serializer,keys, bookId.toString());
        if(!"1".equals(res)){
            return false;
        }

        // 获取库存信息并修改库存，不具备原子性
        /*Integer amount = (Integer)(redisTemplate.opsForHash().get("secondsKillBooks", String.valueOf(bookId)));
        if(amount == null || amount <= 0){
            return false;
        }
        //redis预扣库存
        Long value = redisTemplate.opsForHash().increment("secondsKillBooks", String.valueOf(bookId), -1);
        if(value <= 0){
            // 如果扣完后库存为0，则删除当前商品
            redisTemplate.opsForHash().delete("secondsKillBooks", String.valueOf(bookId));
        }*/

        Order order = new Order();
        order.setOrderId(String.valueOf(SnowflakeIdWorker.generateId()));
        order.setBookId(bookId);
        order.setMoney(bookMapper.selectBookById(bookId).getPrice());
        order.setUserId(userId);
        order.setStatus(0);
        order.setCreateTime(new Date());
        orderProducer.sendOrder(order);
        return true;
    }

    @Override
    public boolean addOrder(Order order) {
        int result;
        result= orderMapper.insertOrder(order);
        if(result > 0){
            Book params = new Book();
            params.setId(order.getBookId());
            params.setAmount(-1);
            try {
                result = bookMapper.updateBook(params);
                if(result > 0){
                    return true;
                }
            } catch (Exception e) {
                System.out.println("库存不足，无法下单!");
            }

        }
        throw new RuntimeException("更新库存失败！");
    }


}
