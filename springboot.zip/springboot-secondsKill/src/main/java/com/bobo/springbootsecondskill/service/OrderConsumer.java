package com.bobo.springbootsecondskill.service;

import com.bobo.springbootsecondskill.config.OrderDirectExchangeConfig;
import com.bobo.springbootsecondskill.entity.Order;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;


@Service
public class OrderConsumer {

    @Autowired
    private OrderService orderService;

    @RabbitListener(queues = OrderDirectExchangeConfig.QUEUE_NAME)
    public void consumerOrder(Message meaasge, Channel channel){
        System.out.println("订单消费者收到消息："+meaasge);

        ObjectMapper mapper = new ObjectMapper();
        Order order = null;
        try {
            order = mapper.readValue(meaasge.getBody(), Order.class);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        //库存同步到mysql
        try {
            boolean result = orderService.addOrder(order);
            if(result){
                System.out.println("下单成功["+new String(meaasge.getBody())+"]!");
            }else{
                System.out.println("下单失败["+new String(meaasge.getBody())+"]!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("下单失败["+new String(meaasge.getBody())+"]!");
        }

    }

}
