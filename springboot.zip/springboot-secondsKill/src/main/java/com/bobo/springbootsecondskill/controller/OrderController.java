package com.bobo.springbootsecondskill.controller;


import com.bobo.springbootsecondskill.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/order/add")
    public String addOrder(@RequestParam(value = "bookId") Long bookId,
                           @RequestParam(value = "userId") Integer userId){
        boolean success = orderService.addOrder(bookId,userId);
        if(success){
            return "下单成功！";
        }
        return "下单失败";
    }
}
