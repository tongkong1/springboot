package com.bobo.springbootsecondskill.mapper;

import com.bobo.springbootsecondskill.entity.Order;
import org.apache.ibatis.annotations.Param;


public interface OrderMapper {
    /**
     * 插入订单
     */
    int insertOrder(@Param("order") Order order);
}
