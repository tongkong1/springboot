package com.bobo.springbootsecondskill.service;

import com.bobo.springbootsecondskill.config.OrderDirectExchangeConfig;
import com.bobo.springbootsecondskill.entity.Order;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class OrderProducer {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    public boolean sendOrder(Order order){
        try {
            rabbitTemplate.convertAndSend(OrderDirectExchangeConfig.EXCHANGE_NAME,
                    OrderDirectExchangeConfig.QUEUE_EXCHANGE_KEY,new ObjectMapper().writeValueAsString(order));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return true;
    }
}
