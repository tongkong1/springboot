package com.bobo.springbootsecondskill;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@MapperScan("com.bobo.springbootsecondskill.mapper")
@EnableCaching
public class SpringbootSecondskillApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootSecondskillApplication.class, args);
    }

}
