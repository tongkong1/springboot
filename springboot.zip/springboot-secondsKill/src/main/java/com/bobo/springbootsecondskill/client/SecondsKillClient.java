package com.bobo.springbootsecondskill.client;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.LockSupport;

public class SecondsKillClient {
    // 请求数量
    private static final int HTTP_REQUEST_COUNT = 10000;
    // 线程唤醒时间
    private static final long UNTIL_TIME = System.currentTimeMillis()+5000;
    private static final String REQUEST_URL = "http://localhost:8080/order/add";

    public void execute(){
        for (int i = 0; i < HTTP_REQUEST_COUNT; i++) {
            Thread t = new Thread(() -> {
                // 阻塞线程，设置指定的时间唤醒
                LockSupport.parkUntil(UNTIL_TIME);

                // 生成随机的bookId
                Long bookId = buildRandomBookId();
                // 生成随机的userId
                Integer userId = buildRandomUserId();

                // 构造post请求
                HttpPost httpPost = new HttpPost(REQUEST_URL);
                List<NameValuePair> params = new ArrayList<>();
                params.add(new BasicNameValuePair("bookId", String.valueOf(bookId)));
                params.add(new BasicNameValuePair("userId", String.valueOf(userId)));

                // 发起http请求
                try(CloseableHttpClient httpclient = HttpClients.createDefault()) {
                    UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, "utf-8");
                    httpPost.setEntity(entity);
                    httpclient.execute(httpPost);
                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("post请求发送失败");
                }
            },"线程"+i+"号！");
            t.start();

        }
    }

    private Long buildRandomBookId(){
        int a = (ThreadLocalRandom.current().nextInt(1000) + 1) % 4;
        switch (a) {
            case 0: return 11L;
            case 1: return 12L;
            case 2: return 13L;
            case 3: return 14L;
            default: return null;
        }
    }
    private Integer buildRandomUserId(){
        return ThreadLocalRandom.current().nextInt(100000) + 50;
    }

    public static void main(String[] args) {
        new SecondsKillClient().execute();
    }
}
