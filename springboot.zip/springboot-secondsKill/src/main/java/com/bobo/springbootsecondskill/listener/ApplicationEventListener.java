package com.bobo.springbootsecondskill.listener;


import com.bobo.springbootsecondskill.entity.Book;
import com.bobo.springbootsecondskill.mapper.BookMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.stream.Collectors;

@Component
public class ApplicationEventListener {
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;
    @Autowired
    private BookMapper bookMapper;
    public static final String SECONDS_BOOK_KEY = "secondsKillBooks";

    @EventListener
    public void contextRefreshedEventListener(ContextRefreshedEvent contextRefreshedEvent) {
        if(redisTemplate == null){return;}
        System.out.println("往redis中加载秒杀商品开始！");
        Book params = new Book();
        params.setSecondsKill(1);
        // 获取操作redis hash类型的操作类
        HashOperations<String, Object, Object> hashOperations = redisTemplate.opsForHash();
        // 查询秒杀商品，并通过流的方式转化为Map,Map的key为商品ID，Map的value为商品库存
        Map<String,Integer> map = bookMapper.selectBooks(params).stream().collect(
                Collectors.toMap(t-> String.valueOf(t.getId()),Book::getAmount));
        // 往redis中加载数据
        hashOperations.putAll(SECONDS_BOOK_KEY,map);

        System.out.println("往redis中加载秒杀商品成功！");
    }
}

