local a=redis.call('exists',KEYS[1]);
if(tonumber(a) ~= 1) then
return 'key不存在'
end;
local b=redis.call('hexists',KEYS[1],ARGV[1]);
if(tonumber(b) ~= 1) then
return 'field不存在'
end;
local c=redis.call('hget',KEYS[1],ARGV[1]);
if(tonumber(c) <= 0) then
redis.call('hdel',KEYS[1],ARGV[1]);
return '库存为空'
else
redis.call('hincrby',KEYS[1],ARGV[1],-1);
return '库存扣减成功'
end