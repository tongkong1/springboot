local val=redis.call('hget',KEYS[1],ARGV[1]);
-- 判断是否为空
if(val == false) then
-- 库存不存在
return '0'
elseif(tonumber(val) <= 0)
then
-- 库存为0
redis.call('hdel',KEYS[1],ARGV[1]);
return '0'
else
-- 下单成功
redis.call('hincrby',KEYS[1],ARGV[1],-1);
return '1'
end